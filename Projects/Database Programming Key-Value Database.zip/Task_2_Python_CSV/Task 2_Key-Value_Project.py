import tkinter as tk
from tkinter import simpledialog, messagebox
import redis
from cryptography.fernet import Fernet
import random
import os
import csv
import unittest

#AES encryption setup
encryption_key = b'2Dg0PgHYDpb5Knb7XZJeTZWcTE6km7xjpx-qmQGEVQM='
fernet = Fernet(encryption_key)

#connection to find a campsite database
def connect_to_find_a_campsite_kv_database():
    """Connects Redis find a campsite database. Replace host, port, and password with Redis key-value database credentials"""
    database_connection = redis.Redis(host='redis-10535.c277.us-east-1-3.ec2.redns.redis-cloud.com',  port=10535,  password='xrTHkCs9gpNLa60gAsLgSnFBlD3VrY7W', decode_responses = True)
    return database_connection

def test_connection(database_connection):
    """Tests connection to find a campsite database with a ping request, returning True if key-value database exists"""
    database_connection.ping()
    print("Ping returned : " + str(database_connection.ping()))

database_connection = connect_to_find_a_campsite_kv_database()
test_connection(database_connection)

result = database_connection.set("Message", "You are connected to the find a campsite key-value database with Python :)")
print("SET Message returned : " + str(result))
result = database_connection.get("Message")
print("GET Message returned : " + str(result))

#creates security questions
def security_questions_creation():
    security_questions = [
        "What is your first ever pet's name?",
        "What was the first school you attended?",
        "What was your favourite place to visit as a child?",
        "What city were you born in?",
        "What is your occupation?"
    ]
    """Clear the list if already filled and re-add"""
    database_connection.delete("current_security_questions")
    for q in security_questions:
        database_connection.rpush("current_security_questions", q)

#security question randomisation
def randomise_security_question():
    total = database_connection.llen("current_security_questions")
    if total == 0:
        raise Exception("No security questions could be found in the database.")
    question_index = random.randint(0, total - 1)
    return database_connection.lindex("current_security_questions", question_index)

#loads the CSV into the Redis database
def initial_database_load(csv_file):
    if not os.path.exists(csv_file):
        print(f"CSV file was not found: {csvfile}. Skipping CSV load.")
        return 0
    count = 0
    with open(csv_file, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            username = row["username"].strip()
            password = row["password"].strip()
            firstname = row["firstname"].strip()

            """Assigns a randomised security question from list"""
            question = randomise_security_question()

            """Encrypts user's password"""
            encrypted_password = fernet.encrypt(password.encode()).decode()
            
            """Key identifier"""
            key = f"user:{username}"
            database_connection.hset(key, mapping={
                "password": encrypted_password,
                "first_name": firstname,
                "security_question": question
            })
            count += 1
    print("Data has loaded from CSV into find a campsite database successfully :)")
    return count

#create an account function
def account_creation():
    username = simpledialog.askstring("Create An Account", "Enter Your Email:")
    if not username: return
    first_name = simpledialog.askstring("Create An Account", "Enter Your First Name:")
    if not first_name: return
    password = simpledialog.askstring("Create An Account", "Enter Your Password:", show="*")
    if not password: return
    question = randomise_security_question()
    answer = simpledialog.askstring("Create An Account", f"Please Answer: {question}")
    if not answer: return

    key = f"user:{username}"
    encrypted_password = fernet.encrypt(password.encode()).decode()
    database_connection.hset(key, mapping = {
        "password": encrypted_password,
        "first_name": first_name,
        "security_question": question,
        "security_answer": answer
    })
    messagebox.showinfo("Your account has been successfully created !!!", parent = root)

#forgot password function
def forgot_password():
    username = simpledialog.askstring("Forgot Password?", "Enter Your Email:")
    if not username: return
    key = f"user:{username}"
    if not database_connection.exists(key):
        messagebox.showerror("Error", "Your username was not found!", parent = root)
        return
    """Either gets the stored security question or assigns a random one"""
    question = database_connection.hget(key, "security_question")
    stored_answer = database_connection.hget(key, "security_answer")

    """Forces a new answer for users stored in CSV if there is no associated answer"""
    if not stored_answer:
        answer = simpledialog.askstring(
            "Forgot Password?",
            f"You don't have a security answer set yet.\nPlease answer this randomly assigned security question:\n{question}"
        )
        if not answer:
            messagebox.showerror("Error", "You must provide an answer to continue!", parent = root)
            return
        database_connection.hset(key, "security_answer", answer)
    else:
        answer = simpledialog.askstring("Forgot Password?", f"{question}")
        if answer != stored_answer:
            messagebox.showerror("Error", "Incorrect Answer!", parent = root)
            return
    
    """Allows successful password reset"""
    new_password = simpledialog.askstring("Forgot Password", "Enter New Password:", show = "*")
    if not new_password:
        return
    encrypted_password = fernet.encrypt(new_password.encode()).decode()
    database_connection.hset(key, "password", encrypted_password)
    messagebox.showinfo("Success", "Your password was reset successfully!", parent = root)

#login function
def login():
    username = simpledialog.askstring("Login", "Enter Your Email:")
    if not username: return
    password = simpledialog.askstring("Login", "Enter Your Password:", show = "*")
    if not password: return
    key = f"user:{username}"
    if not database_connection.exists(key):
        messagebox.showerror("Error", "Username couldn't be found!", parent = root)
        return
    stored_encrypted = database_connection.hget(key, "password")
    try:
        stored_password = fernet.decrypt(stored_encrypted.encode()).decode()
    except Exception:
        messagebox.showerror("Error", "Password could not be encrypted due to old encryption key.", parent = root)
        return
    if password == stored_password:
        messagebox.showinfo("Success", f"Welcome {database_connection.hget(key,'first_name')}!", parent = root)
    else:
        messagebox.showerror("Error", "Incorrect Password!", parent=root)

#database flush, reset, and fresh data load
"""comment in/out depending on if you want the database flushed after every new run"""
#database_connection.flushdb()
#print("Redis database has been flushed, all previous data has been successfully cleared!")
database_connection.set("Message", "You are connected to the find a campsite key-value database with Python :)")

#security questions setup
security_questions_creation()
print("Successfully added security questions to all current accounts :)")

#load in process
print("Be patient, CSV is loading into database ...")
print("Expect a GUI popup in about a minute :)")

#loads initial CSV data
script_dir = os.path.dirname(os.path.abspath(__file__))
csv_file = os.path.join(script_dir, "ICT320-Task2-Initial-Database.csv")
user_count = initial_database_load(csv_file)

#main menu GUI window
root = tk.Tk()
root.title("Find a Campsite Login")
root.geometry("300x220")
root.resizable(False, False)
root.lift()
root.attributes('-topmost', True)
root.after(1000, lambda: root.attributes('-topmost', False))

tk.Label(root, text="Welcome to Find a Campsite", font=("Arial", 14)).pack(pady=10)
tk.Button(root, text="Login", width=25, command=login).pack(pady=5)
tk.Button(root, text="Create Account", width=25, command=account_creation).pack(pady=5)
tk.Button(root, text="Forgot Password", width=25, command=forgot_password).pack(pady=5)
tk.Button(root, text="Exit", width=25, command=root.destroy).pack(pady=5)

"""GUI message displaying database setup is confirmed"""
messagebox.showinfo("Database is ready", f"Redis has been successfully loaded!\n{user_count} users have been loaded in.", parent = root)

#automated tests on script
def automated_tests():
    print("\nRunning automated test scripts :)")

    """Test case 1: account creation"""
    username = "test@email.com"
    first_name = "Test"
    password = "Password123"
    question = randomise_security_question()
    answer = "Answer123"
    encrypted_password = fernet.encrypt(password.encode()).decode()

    fake_user = {
        "username": username,
        "password": encrypted_password,
        "first_name": first_name, #replace first_name with "" to force fail; otherwise use first_name to pass
        "security_question": question,
        "security_answer": answer
    }

    if fake_user["first_name"] == first_name:
        print("[PASS] Account Creation")
    else:
        print("[FAIL] Account Creation")

    """Test case 2: successful login"""
    if fernet.decrypt(fake_user["password"].encode()).decode() == password: #replace password with "WrongPassword" to force fail; otherwise use password to pass
        print("[PASS] Successful Login")
    else:
        print("[FAIL] Failed Login")

    """Test case 3: failed login"""
    wrong_pass = "WrongPass" #replace "WrongPass" with "Password123" to force fail; otherwise use "WrongPass" to pass
    if fernet.decrypt(fake_user["password"].encode()).decode() != wrong_pass:
        print("[PASS] Login Failure Was Correctly Rejected")
    else:
        print("[FAIL] Login Failure Test")

    """Test case 4: forgot password"""
    new_password = "NewPassword123"
    fake_user["password"] = fernet.encrypt(new_password.encode()).decode()
    if fernet.decrypt(fake_user["password"].encode()).decode() == new_password: #replace new_password with "NotNewPassword" to force fail; otherwise use new_password to pass
        print("[PASS] Forgot Password")
    else:
        print("[FAIL] Forgot Password Test")

#runs automated tests function
automated_tests()

#unit tests on script
class TestFindACampsite(unittest.TestCase):
    print("\nRunning unit test scripts :)")

    def test_account_creation(self):
        key = "user:unit_test_account"
        username = "unit_test_account"
        first_name = "Unit"
        password = "UnitPass123"
        question = randomise_security_question()
        answer = "UnitAnswer"
        encrypted_password = fernet.encrypt(password.encode()).decode()

        """Create test account"""
        database_connection.hset(key, mapping = {
            "username": username,
            "password": encrypted_password,
            "first_name": first_name,
            "security_question": question,
            "security_answer": answer
        })

        """Validate"""
        stored = database_connection.hgetall(key)
        self.assertEqual(stored["first_name"], first_name)
        self.assertEqual(stored["security_question"], question)
        self.assertEqual(stored["security_answer"], answer)
        self.assertEqual(fernet.decrypt(stored["password"].encode()).decode(), password)

        """Clean up"""
        database_connection.delete(key)

    def test_security_questions_list(self):
        total = database_connection.llen("current_security_questions")
        self.assertGreater(total, 0)
        question = randomise_security_question()
        questions_list = database_connection.lrange("current_security_questions", 0, -1)
        self.assertIn(question, questions_list)

    def test_login_success(self):
        key = "user:unit_test_login"
        username = "unit_test_login"
        first_name = "LoginUnit"
        password = "LoginPass123"
        question = randomise_security_question()
        answer = "LoginAnswer"
        encrypted_password = fernet.encrypt(password.encode()).decode()

        """Create test login user"""
        database_connection.hset(key, mapping = {
            "username": username,
            "password": encrypted_password,
            "first_name": first_name,
            "security_question": question,
            "security_answer": answer
        })

        """Validate login"""
        stored_encrypted = database_connection.hget(key, "password")
        stored_password = fernet.decrypt(stored_encrypted.encode()).decode()
        self.assertEqual(stored_password, password)
        self.assertNotEqual(stored_password, "WrongPass")

        """Clean up"""
        database_connection.delete(key)

#run unit tests and launch GUI
if __name__ == "__main__":
    """Runs unit tests"""
    unittest.main(exit = False)
    """Launches the GUI"""
    root.mainloop()
