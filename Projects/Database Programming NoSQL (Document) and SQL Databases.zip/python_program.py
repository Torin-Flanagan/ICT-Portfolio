#LIBRARY IMPORTS FOR ALL NECESSARY MODULES RELEVANT TO THE PROGRAM
from pymongo import MongoClient
from bson.objectid import ObjectId
from datetime import date, datetime
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
import os
import pyodbc

#SQL CONNECTION
def azure_sql_database_connection():
    """Establish a stable active connection to Azure SQL database (username and password may be required on Azure to activate session)."""
    server = 'ict320-task3-sql-tf.database.windows.net'
    database = 'ict320-task3-sql'
    username = 'ict320task3'
    password = 'Password1'
    driver = '{ODBC Driver 18 for SQL Server}'
    sql_connection_string = (
        f'DRIVER={driver};'
        f'SERVER={server},1433;'
        f'DATABASE={database};'
        f'UID={username};'
        f'PWD={password};'
        f'Encrypt=yes;'
        f'TrustServerCertificate=no;'
        f'Connection Timeout=30;'
    )
    sql_connection = pyodbc.connect(sql_connection_string)
    return sql_connection
sql_connection = azure_sql_database_connection()

def test_connection(sql_connection):
    """Tests SQL database connection by executing a simply query."""
    try:
        cursor = sql_connection.cursor()
        cursor.execute("SELECT 1")
        result = cursor.fetchone()
        print("\nConnection successful! Test query returned:", result[0], '\n')
    except Exception as e:
        print("\nConnection failed:", e)
test_connection(sql_connection)

#INPUT VALIDATION HELPER
def get_valid_input(prompt, validation_function, error_message):
    """Prompts for user input until validation function is passed."""
    while True:
        value = input(prompt).strip()
        if validation_function(value):
            return value
        print(error_message)

#NoSQL (MongoDB) CONNECTION
"""Establish a stable active connection to Azure NoSQL database."""
MONGO_URI = "mongodb://ict320-tf-db:e4NL4HzseQRqZfgRpMPG4S0vfQGFlWxqwWDWaZ2pwjNRnv3v2eMeGapaPLcznhVRkAHDmP69OtmjACDbbEUlxQ==@ict320-tf-db.mongo.cosmos.azure.com:10255/?ssl=true&replicaSet=globaldb&retrywrites=false&maxIdleTimeMS=120000&appName=@ict320-tf-db@"
client = MongoClient(MONGO_URI)
db = client["Joes_Pizzeria_DB"]
customers, orders, drivers, dockets = db["customers"], db["orders"], db["drivers"], db["dockets"]
print("Connected to NoSQL database and all collections have been initialised.\n")

#CLEAR NoSQL DATABASE
def clear_db():
    """Removes all documents from all collections."""
    for col in [customers, drivers, orders, dockets]:
        col.delete_many({})
    print("All collections cleared.\n")

#ADD CUSTOMER
def add_customer(first, last, phone, email, street, suburb, postcode):
    """Creates and stores a new customer to the NoSQL database, otherwise returing the existing ID if already stored."""
    existing = customers.find_one({"email": email})
    if existing:
        print(f"Customer already exists: {existing['_id']}")
        return existing["_id"]
    customer = {
        "first_name": first,
        "last_name": last,
        "phone": phone,
        "email": email,
        "address": {"street": street, "suburb": suburb, "postcode": postcode},
    }
    result = customers.insert_one(customer)
    print(f"Customer added, ID: {result.inserted_id}")
    return result.inserted_id

#AUTOMATICALLY ADD DRIVER
def add_driver_auto(name, suburbs, rate=10.0):
    """Automatically adds driver to NoSQL database (used to initially populate database with test driver data)."""
    existing = drivers.find_one({"name": name})
    if existing:
        print(f"Driver already exists: {existing['_id']}")
        return existing["_id"]
    driver = {
        "name": name,
        "delivery_suburbs": suburbs,
        "commission_rate": float(rate),
        "is_active": True,
    }
    result = drivers.insert_one(driver)
    print(f"Driver added automatically, ID: {result.inserted_id}")
    return result.inserted_id

#MANUALLY ADD DRIVER
def add_driver():
    """Manually adds driver to NoSQL database through interactive prompts."""
    name = get_valid_input(
        "Driver Name: ",
        lambda x: x.replace(" ", "").isalpha() and 1 <= len(x) <= 50,
        "Invalid driver name. Must be only letters and between 1-50 characters."
    )
    suburbs = []
    while True:
        suburb = get_valid_input(
            "Enter Delivery Suburb: ",
            lambda x: x.replace(" ", "").isalpha() and 1 <= len(x) <= 50,
            "Invalid suburb. Must be only letters and between 1-50 characters."
        )
        suburbs.append(suburb)
        while True:
            add_suburb = input("Add another suburb? (y/n: )").lower().strip()
            if add_suburb in ['y', 'n']:
                break
            print("Invalid input. Please enter 'y' for yes or 'n' for no.")
        if add_suburb == 'y':
            continue
        else:
            break
    while True:
        commission_input = input("Commission rate (default 10.00%): ").strip()
        if commission_input == "":
            rate = 10.00
            break
        try:
            rate = float(commission_input)
            if 10.00 <= rate <= 100.00:
                break
            print("Commission rate must be between 0.00 and 100.00.")
        except ValueError:
            ("Invalid input. Please enter a number or leave blank for default commission rate (10.00%).")
    existing = drivers.find_one({"name": name})
    if existing:
        print(f"Driver already exists: {existing['_id']}")
        return existing["_id"]
    result = drivers.insert_one({
        "name": name,
        "delivery_suburbs": suburbs,
        "commission_rate": rate,
        "is_active": True,
    })
    print(f"Driver added successfully! ID: {result.inserted_id}")
    return result.inserted_id

#ADD ORDER
def add_order(customer_id, pizzas, driver_id, status="Cooking"):
    """Adds a new order with both cooking and delivery dockets combined."""
    today_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    total = sum(p["quantity"] * p["price"] for p in pizzas)
    order = {
        "customer_id": ObjectId(customer_id),
        "order_date": datetime.now(),
        "order_date_only": today_date,
        "pizzas": pizzas,
        "total_price": float(total),
        "driver_id": ObjectId(driver_id),
        "status": status,
    }
    result = orders.insert_one(order)
    order_id = result.inserted_id
    print(f"Order added, ID: {order_id}, Total: ${total:.2f}")
    customer = customers.find_one({"_id": ObjectId(customer_id)})
    driver = drivers.find_one({"_id": ObjectId(driver_id)})
    commission = round(total * driver["commission_rate"] / 100, 2)
    cooking_docket = {
        "docket_type": "Cooking",
        "order_id": str(order_id),
        "order_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "customer_info": {k: customer[k] for k in ["first_name", "last_name", "email"]},
        "ordered_items": pizzas,
        "status": status,
    }
    delivery_docket = {
        "docket_type": "Delivery",
        "order_id": str(order_id),
        "order_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "customer_info": {
            **{k: customer[k] for k in ["first_name", "last_name", "phone"]},
            "address": customer.get("address", {}),
        },
        "driver_info": {
            "name": driver["name"],
            "delivery_suburbs": driver["delivery_suburbs"],
            "commission_rate": driver["commission_rate"],
            "commission_amount": commission,
        },
        "order_summary": {
            "total_price": total,
            "item_count": sum(i["quantity"] for i in pizzas),
        },
        "ordered_items": pizzas,
        "status": status,
    }
    dockets.insert_many([cooking_docket, delivery_docket])
    print("Cooking and Delivery dockets stored in database.")
    generate_pdf_from_order(str(order_id))
    return order_id

#MANUALLY PLACE ORDER
def place_order():
    """Places a new order with customer, pizza/s, and driver selection through interactive prompts."""
    print("\n:::: New Customer Order ::::")
    email = get_valid_input(
        "Enter customer email: ",
        lambda e: "@" in e and "." in e and 5 <= len(e) <= 50,
        "Invalid email format (valid example: valid@email.com )."
    )
    existing = customers.find_one({"email": email})
    if existing:
        customer_id = existing["_id"]
        print("Returning existing customer details.")
    else:
        print("New customer detected.")
        first = get_valid_input("First Name: ", lambda x: x.isalpha() and 1 <= len(x) <= 50, "Invalid name. Must be between 1-50 characters.")
        last = get_valid_input("Last Name: ", lambda x: x.isalpha() and 1 <= len(x) <= 50, "Invalid name. Must be between 1-50 characters.")
        phone = get_valid_input("Phone (10 digits): ", lambda x: x.isdigit() and len(x) == 10, "Invalid phone number. Must be 10 digits.")
        address = get_valid_input("Address: ", lambda x: 1 <= len(x) <= 50, "Invalid address. Must be between 1-50 characters.")
        suburb = get_valid_input("Suburb: ", lambda x: all(c.isalpha() or c.isspace() or c in "-'" for c in x) and 1 <= len(x) <= 50, "Invalid suburb. Must be between 1-50 characters (containing only letters, spaces, hyphens, or apostrophes).")
        postcode = get_valid_input("Postcode (4 digits): ", lambda x: x.isdigit() and len(x) == 4, "Invalid postcode. Must be 4 digits.")
        customer_id = add_customer(first, last, phone, email, address, suburb, postcode)
    menu = {"Pepperoni": 15.0, "Garlic": 12.5, "Hawaiian": 17.5, "Margherita": 10.0}
    pizzas = []
    while True:
        for i, (n, p) in enumerate(menu.items(), 1):
            print(f"{i}. {n} (${p:.2f})")
        try:
            choice = int(input("Select pizza (1-4): ").strip())
            if 1 <= choice <= 4:
                pizza_name = list(menu.keys())[choice - 1]
                price = menu[pizza_name]
            else:
                print("Invalid choice. Must be 1-4."); continue
        except ValueError:
            print("Enter a number between 1-4."); continue
        
        size = get_valid_input("Size (S/M/L): ", lambda s: s.upper() in ["S", "M", "L"], "Invalid size. Must be S/M/L.")
        quantity = get_valid_input("Quantity (1–10): ", lambda q: q.isdigit() and 1 <= int(q) <= 10, "Invalid quantity. Must be 1-10.")
        pizzas.append({"pizza_name": pizza_name, "size": size.upper(), "quantity": int(quantity), "price": price})
        while True:
            add_more = input("Add another pizza? (y/n): ").lower().strip()
            if add_more in ['y', 'n']:
                break
            print("Invalid input. Enter 'y' for yes or 'n' for no.")
        if add_more == 'y':
            continue
        else:
            break
    drivers_list = list(drivers.find({"is_active": True}))
    for i, d in enumerate(drivers_list, 1):
        print(f"{i}. {d['name']} ({', '.join(d['delivery_suburbs'])})")
    while True:
        choice_input = input("Select driver: ").strip()
        if not choice_input.isdigit():
            print("Please enter a number corresponding to a driver.")
            continue
        choice = int(choice_input)
        if 1 <= choice <= len(drivers_list):
            driver_id = drivers_list[choice - 1]["_id"]
            break
        print(f"Invalid driver number. Must be 1 through to {len(drivers_list)}.")
    add_order(customer_id, pizzas, driver_id)
    print("\nOrder placed successfully. Cooking and Delivery dockets are already in the database.")

#GENERATE NoSQL ORDER DOCKET PDF FROM DOCKET STORAGE
def generate_pdf_from_order(order_id_input = None):
    """Generates a combined PDF with both the cooking and delivery docket, relevant to the specific order (order ID)."""
    while True:
        if not order_id_input:
            order_id_input = input("Enter order ID from database: ").strip()
        try:
            order_id = str(ObjectId(order_id_input))
            break
        except Exception:
            print("Invalid Order ID format. Must be a valid 24-character ObjectId.")
            order_id_input = None
    order_obj = orders.find_one({"_id": ObjectId(order_id)})
    if not order_obj:
        print("Order not found in NoSQL database.")
        return
    order_dockets = list(dockets.find({"order_id": order_id}))
    if not order_dockets:
        print("No dockets found for this order in the database.")
        return
    for docket in order_dockets:
        docket["status"] = order_obj.get("status", "N/A")
    os.makedirs("Pizzaria_Exports", exist_ok = True)
    fname = f"Pizzaria_Exports/order_{order_id}.pdf"
    c = canvas.Canvas(fname, pagesize=A4)
    for docket in order_dockets:
        y = A4[1] - 50
        c.setFont("Helvetica-Bold", 18)
        c.drawString(50, y, "Joe's Pizzeria")
        y -= 25
        c.setFont("Helvetica-Bold", 18)
        c.drawString(50, y, f"{docket['docket_type']} Docket")
        y -= 30
        c.setFont("Helvetica", 12)
        c.drawString(50, y, f"Order ID: {docket['order_id']}")
        y -= 20
        c.drawString(50, y, f"Order Date: {docket['order_date']}")
        y -= 20
        c.drawString(50, y, f"Status: {docket.get('status', 'N/A')}")
        y -= 30
        if docket["docket_type"] == "Cooking":
            c.setFont("Helvetica-Bold", 13)
            c.drawString(50, y, "Cooking Details")
            y -= 20
            c.setFont("Helvetica", 12)
            c.drawString(50, y, f"Customer: {docket['customer_info']['first_name']} {docket['customer_info']['last_name']}")
            y -= 20
            c.drawString(50, y, f"Email: {docket['customer_info'].get('email', 'N/A')}")
            y -= 30
            c.setFont("Helvetica-Bold", 12)
            c.drawString(50, y, "Ordered Items:")
            y -= 20
            total = 0
            for p in docket["ordered_items"]:
                subtotal = p['quantity'] * p['price']
                c.drawString(60, y, f"- {p['quantity']}x {p['size']} {p['pizza_name']} @ ${p['price']:.2f} = ${subtotal:.2f}")
                total += subtotal
                y -= 20
            y -= 10
            c.setFont("Helvetica-Bold", 12)
            c.drawString(50, y, f"Total for Order: ${total:.2f}")
        elif docket["docket_type"] == "Delivery":
            c.setFont("Helvetica-Bold", 13)
            c.drawString(50, y, "Delivery Details")
            y -= 20
            c.setFont("Helvetica", 12)
            ci = docket["customer_info"]
            addr = ci.get("address", {})
            c.drawString(50, y, f"Customer: {ci['first_name']} {ci['last_name']}  |  Phone: {ci.get('phone', 'N/A')}")
            y -= 20
            c.drawString(50, y, f"Address: {addr.get('street', '')}, {addr.get('suburb', '')}, {addr.get('postcode', '')}")
            y -= 30
            driver = docket.get("driver_info", {})
            c.setFont("Helvetica-Bold", 12)
            c.drawString(50, y, "Driver Information:")
            y -= 20
            c.setFont("Helvetica", 12)
            c.drawString(50, y, f"Name: {driver.get('name', 'N/A')}")
            y -= 20
            c.drawString(50, y, f"Commission Rate: {driver.get('commission_rate', 0):.2f}%")
            y -= 20
            c.drawString(50, y, f"Commission Amount: ${driver.get('commission_amount', 0):.2f}")
            y -= 30
            c.setFont("Helvetica-Bold", 12)
            c.drawString(50, y, "Ordered Items:")
            y -= 20
            order_summary = docket.get("order_summary", {})
            for p in docket["ordered_items"]:
                c.drawString(60, y, f"- {p['quantity']}x {p['size']} {p['pizza_name']} @ ${p['price']:.2f}")
                y -= 20
            y -= 10
            c.setFont("Helvetica-Bold", 12)
            c.drawString(50, y, f"Total Items: {order_summary.get('item_count', 'N/A')}")
            y -= 20
            c.drawString(50, y, f"Total Price: ${order_summary.get('total_price', 0):.2f}")
        c.showPage()
    c.save()
    print(f"Combined PDF (Cooking + Delivery) saved to {os.path.abspath(fname)}")

#VIEW ORDERS
def view_order():
    """Displays all orders stored in the NoSQL database, also containing customer and driver information."""
    print("\n:::: ALL ORDERS ::::")
    all_orders = list(orders.find())
    if not all_orders:
        print("\nNo orders were  found in the database.\n")
        return
    for o in all_orders:
        c = customers.find_one({"_id": o["customer_id"]})
        d = drivers.find_one({"_id": o["driver_id"]})
        print(f"\nOrder ID: {o['_id']}\nCustomer: {c['first_name']} {c['last_name']} ({c['email']})")
        print(f"Driver: {d['name']}\nStatus: {o['status']}\nTotal: ${o['total_price']:.2f}")
        for p in o["pizzas"]:
            print(f" - {p['quantity']}x {p['size']} {p['pizza_name']} @ ${p['price']:.2f}")

#MARK ORDER READY
def mark_order_ready():
    """Updates the order status to 'Ready' through interactive prompts."""
    while True:
        order_id_input = input("Enter order ID to mark order as ready: ").strip()
        try:
            oid = ObjectId(order_id_input)
            break
        except Exception:
            print("Invalid order ID format. Must be a valid 24-character ObjectId.")
    result = orders.update_one({"_id": oid}, {"$set": {"status": "Ready"}})
    if result.modified_count:
        print("Order marked as READY.")
    else:
        print("Order not found or is already ready.")

#VIEW DRIVERS
def view_drivers():
    """Displays all active drivers with their delivery suburbs and commission rate."""
    print("\n:::: ACTIVE DRIVERS ::::")
    for d in drivers.find({"is_active": True}):
        print(f"{d['name']} | Suburbs: {', '.join(d['delivery_suburbs'])} | Commission: {d['commission_rate']}%")

#DAILY SUMMARY GENERATION
def generate_daily_summary(sql_connection, summary_date=None):
    """Generates and stores a daily summary of all orders by date, storing summaries in the SQL database."""
    if summary_date is None:
        summary_date = date.today()
    sql_cursor = sql_connection.cursor()
    start = datetime.combine(summary_date, datetime.min.time())
    end = datetime.combine(summary_date, datetime.max.time())
    daily_orders = list(orders.find({
        "order_date": {"$gte": start, "$lte": end}
    }))
    if not daily_orders:
        print(f"No orders found for {summary_date}.")
        return
    total_orders = len(daily_orders)
    total_sales_revenue = 0
    pizza_counter = {}
    total_driver_commission = 0
    for order in daily_orders:
        pizzas = order.get("pizzas", [])
        driver_id = order.get("driver_id")
        order_total = sum(p["price"] * p.get("quantity", 1) for p in pizzas)
        total_sales_revenue += order_total
        for p in pizzas:
            pizza_counter[p["pizza_name"]] = pizza_counter.get(p["pizza_name"], 0) + p.get("quantity", 1)
        if driver_id:
            driver = drivers.find_one({"_id": driver_id})
            if driver:
                total_driver_commission += order_total * (driver.get("commission_rate", 10.0) / 100.0)
    most_popular_pizza = max(pizza_counter, key=pizza_counter.get) if pizza_counter else "N/A"
    sql_cursor.execute("SELECT total_orders FROM Pizzeria_Daily_Summaries WHERE summary_date = ?", (summary_date,))
    existing_summary = sql_cursor.fetchone()
    if existing_summary:
        sql_cursor.execute("""
            UPDATE Pizzeria_Daily_Summaries
            SET total_orders = ?, total_sales_revenue = ?, most_popular_pizza = ?, total_driver_commission = ?
            WHERE summary_date = ?
        """, (total_orders, total_sales_revenue, most_popular_pizza, total_driver_commission, summary_date))
    else:
        sql_cursor.execute("""
            INSERT INTO Pizzeria_Daily_Summaries (summary_date, total_orders, total_sales_revenue, most_popular_pizza, total_driver_commission)
            VALUES (?, ?, ?, ?, ?)
        """, (summary_date, total_orders, total_sales_revenue, most_popular_pizza, total_driver_commission))
    sql_connection.commit()
    print(f"\nDaily summary for {summary_date} updated successfully!")
    print(f"Total Orders: {total_orders}")
    print(f"Total Sales Revenue: ${total_sales_revenue:.2f}")
    print(f"Most Popular Pizza: {most_popular_pizza}")
    print(f"Total Driver Commission: ${total_driver_commission:.2f}")

#GENERATE DAILY SUMMARY PDF
def generate_daily_summary_pdf(sql_connection, summary_date = None):
    """Generates a PDF of the daily summary report stored in the SQL database for a given date."""
    if summary_date is None:
        summary_date = date.today()
    os.makedirs("Pizzaria_Exports/Summaries", exist_ok=True)
    pdf_filename = f"Pizzaria_Exports/Summaries/daily_summary_{summary_date}.pdf"
    c = canvas.Canvas(pdf_filename, pagesize=A4)
    width, height = A4
    y = height - 80
    c.setFont("Helvetica-Bold", 20)
    c.drawString(50, y, "Joe's Pizzeria - Daily Summary Report")
    y -= 40
    c.setFont("Helvetica", 12)
    c.drawString(50, y, f"Summary Date: {summary_date}")
    y -= 30
    start = datetime.combine(summary_date, datetime.min.time())
    end = datetime.combine(summary_date, datetime.max.time())
    daily_orders = list(orders.find({"order_date": {"$gte": start, "$lte": end}}))
    total_orders = len(daily_orders)
    total_sales = sum(o["total_price"] for o in daily_orders)
    pizza_counts = {}
    for o in daily_orders:
        for p in o["pizzas"]:
            pizza_counts[p["pizza_name"]] = pizza_counts.get(p["pizza_name"], 0) + p["quantity"]
    most_popular_pizza = max(pizza_counts, key=pizza_counts.get) if pizza_counts else "N/A"
    total_driver_commission = 0
    for o in daily_orders:
        driver = drivers.find_one({"_id": o["driver_id"]})
        if driver:
            total_driver_commission += round(o["total_price"] * driver.get("commission_rate", 0) / 100, 2)
    c.drawString(50, y, f"Total Orders: {total_orders}")
    y -= 20
    c.drawString(50, y, f"Total Sales Revenue: ${total_sales:.2f}")
    y -= 20
    c.drawString(50, y, f"Most Popular Pizza: {most_popular_pizza}")
    y -= 20
    c.drawString(50, y, f"Total Driver Commission: ${total_driver_commission:.2f}")
    y -= 40
    c.setFont("Helvetica-Bold", 14)
    c.drawString(50, y, "Orders Summary:")
    y -= 25
    c.setFont("Helvetica", 11)
    if not daily_orders:
        c.drawString(50, y, "No orders were found for this date.")
    else:
        for o in daily_orders:
            cust = customers.find_one({"_id": o["customer_id"]})
            line = f"- {cust['first_name']} {cust['last_name']} | ${o['total_price']:.2f} | {o['status']}"
            c.drawString(50, y, line)
            y -= 15
            if y < 100:
                c.showPage()
                y = height - 100
                c.setFont("Helvetica", 11)
    c.save()
    print(f"Daily summary PDF saved: {os.path.abspath(pdf_filename)}\n")

#SQL SUMMARY VIEWS
def view_sql_summaries(sql_connection):
    """Displays all daily summaries stored in the SQL database."""
    sql_cursor = sql_connection.cursor()
    sql_cursor.execute("SELECT * FROM Pizzeria_Daily_Summaries ORDER BY summary_date DESC")
    rows = sql_cursor.fetchall()
    if not rows:
        print("\nNo daily summaries could be found in SQL database. Generating summary for today ...\n")
        generate_daily_summary(sql_connection)
        sql_cursor.execute("SELECT * FROM Pizzeria_Daily_Summaries ORDER BY summary_date DESC")
        rows = sql_cursor.fetchall()
    print("\n :::: DAILY SUMMARIES (SQL) ::::")
    for row in rows:
        summary_date = row[0]
        total_orders_number = int(row[1])
        total_sales_revenue = float(row[2])
        most_popular_pizza = str(row[3])
        total_driver_commission = float(row[4])
        print(f"Summary Date: {summary_date} | Total Orders: {total_orders_number} | Total Sales Revenue: ${total_sales_revenue:.2f} | Most Popular Pizza: {most_popular_pizza} | Total Driver Commission: ${total_driver_commission:.2f}")
    print()

#MAIN MENU INTERACTION
def main_menu():
    """Interactive main menu area available through the terminal, providing navigation for all Joe's Pizzeria System functionalities."""
    while True:
        print("\n:::: JOE'S PIZZERIA - MAIN MENU ::::")
        options = ["Place new customer order", "View all orders", "Mark order as ready", "Add new driver", "Generate PDF docket", "View drivers", "Generate daily summary (SQL)", "View daily summaries (SQL)", "Generate daily summary PDF", "Wipe database", "Exit"]
        for i, o in enumerate(options, 1):
            print(f"{i}. {o}")
        choice = input("Pick your action (1–11): ").strip()
        actions = {
            "1": place_order,
            "2": view_order,
            "3": mark_order_ready,
            "4": add_driver,
            "5": generate_pdf_from_order,
            "6": view_drivers,
            "7": lambda: generate_daily_summary(sql_connection),
            "8": lambda: view_sql_summaries(sql_connection),
            "9": lambda: generate_daily_summary_pdf(sql_connection),
            "10": lambda: clear_db() if input("Wipe DB? (y/n): ").lower() == "y" else None,
            "11": lambda: exit(print("Goodbye!"))
        }
        actions.get(choice, lambda: print("Invalid option."))()

#DEMO DATA INSERT AND PROGRAM START
if __name__ == "__main__":
    """Inserts demo data (drivers, customers, and orders) and starts the program by calling the main menu."""
    #clear_db() #Comment out if you don't want to clear NoSQL database everytime re-running the program.
    add_driver_auto("Bob", ["Sippy Downs", "Buderim", "Maroochydore", "Coolum"], 10.00)
    add_driver_auto("Tim", ["Mooloolaba", "Kawana"], 12.75)
    add_driver_auto("Chloe", ["Golden Beach", "Caloundra", "Buddina"], 15.50)
    c1 = add_customer("John", "McDonald", "0412345678", "johnmcdonald@gmail.com", "12 Restaurant Street", "Buderim", "4556")
    c2 = add_customer("Amber", "Brown", "0498765432", "amberbrown@outlook.com", "45 Colour Place", "Golden Beach", "4551")
    if not orders.find_one({"customer_id": c1}):
        add_order(c1, [{"pizza_name": "Margherita", "size": "L", "quantity": 3, "price": 18.5}], drivers.find_one({"name": "Bob"})["_id"])
    if not orders.find_one({"customer_id": c2}):
        add_order(c2, [{"pizza_name": "Pepperoni", "size": "M", "quantity": 4, "price": 15.0}], drivers.find_one({"name": "Chloe"})["_id"])
    main_menu()