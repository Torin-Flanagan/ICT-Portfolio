#LIBRARY IMPORTS FOR ALL NECESSARY MODULES RELEVANT TO PROGRAM TESTING
import unittest
from unittest.mock import MagicMock, patch
from datetime import date, datetime
from bson.objectid import ObjectId
import python_program

#UNIT TEST SUITE
class TestPizzeriaProgram(unittest.TestCase):
    """All unit tests for the Joe's Pizzeria python program (includes NoSQL, SQL, and PDF operations)."""
    #TEST ENVIRONMENT SETUP
    def setUp(self):
        """Patches NoSQL collections and creates mock SQL connection for isolated tests."""
        self.customers_patch = patch.object(python_program, "customers", autospec=True)
        self.orders_patch = patch.object(python_program, "orders", autospec=True)
        self.drivers_patch = patch.object(python_program, "drivers", autospec=True)
        self.dockets_patch = patch.object(python_program, "dockets", autospec=True)
        self.customers = self.customers_patch.start()
        self.orders = self.orders_patch.start()
        self.drivers = self.drivers_patch.start()
        self.dockets = self.dockets_patch.start()
        self.sql_connection = MagicMock()
        self.cursor = self.sql_connection.cursor.return_value

    #TEST ENVIRONMENT TEARDOWN
    def tearDown(self):
        """Stops all active patches to clean up after each test."""
        patch.stopall()

    #HELPER FUNCTION TESTS
    def test_get_valid_input_validates(self):
        """Tests get_valid_input repeatedly prompts until a valid input is recieved."""
        with patch("builtins.input", side_effect=["bad", "good"]):
            result = python_program.get_valid_input("Enter value: ", lambda x: x == "good", "Invalid")
            self.assertEqual(result, "good")

    #NoSQL CUSTOMER TESTS
    def test_add_customer_inserts_new(self):
        """Tests that a new customer is inserted into the NoSQL collection."""
        self.customers.find_one.return_value = None
        fake_result = MagicMock(inserted_id=ObjectId())
        self.customers.insert_one.return_value = fake_result
        cid = python_program.add_customer("John", "Doe", "1234567890", "john@example.com", "1 Main", "Sunny", "4000")
        self.customers.insert_one.assert_called_once()
        self.assertEqual(cid, fake_result.inserted_id)
    
    def test_add_customer_existing(self):
        """Tests that an existing customer ID is returned without re-inserting."""
        existing_id = ObjectId()
        self.customers.find_one.return_value = {"_id": existing_id}
        cid = python_program.add_customer("John", "Doe", "1234567890", "john@example.com", "1 Main", "Sunny", "4000")
        self.assertEqual(cid, existing_id)

    #NoSQL DRIVER TESTS
    def test_add_driver_auto_new(self):
        """Tests that a new driver is inserted automatically into the NoSQL collection."""
        self.drivers.find_one.return_value = None
        fake_result = MagicMock(inserted_id=ObjectId())
        self.drivers.insert_one.return_value = fake_result
        did = python_program.add_driver_auto("Bob", ["Sunnybank"], 10.0)
        self.drivers.insert_one.assert_called_once()
        self.assertEqual(did, fake_result.inserted_id)

    def test_add_driver_auto_existing(self):
        """Tests that an existing driver ID is returned without re-inserting."""
        existing_id = ObjectId()
        self.drivers.find_one.return_value = {"_id": existing_id}
        did = python_program.add_driver_auto("Bob", ["Sunnybank"], 10.0)
        self.assertEqual(did, existing_id)

    #ORDER TESTS
    @patch("python_program.generate_pdf_from_order")
    def test_add_order_creates_dockets(self, mock_pdf):
        """Tests that adding an order creates cooking and delivery dockets, and triggers PDF generation."""
        cust_id = ObjectId()
        driver_id = ObjectId()
        pizzas = [{"pizza_name": "Pepperoni", "quantity": 2, "price": 15.0}]
        self.customers.find_one.return_value = {"first_name": "John", "last_name": "Doe", "email": "john@example.com", "phone": "123", "address": {"street": "A", "suburb": "B", "postcode": "4000"}}
        self.drivers.find_one.return_value = {"name": "Bob", "delivery_suburbs": ["Sunnybank"], "commission_rate": 10.0}
        fake_result = MagicMock(inserted_id=ObjectId())
        self.orders.insert_one.return_value = fake_result
        oid = python_program.add_order(cust_id, pizzas, driver_id)
        self.orders.insert_one.assert_called_once()
        self.dockets.insert_many.assert_called_once()
        mock_pdf.assert_called_once()
        self.assertEqual(oid, fake_result.inserted_id)

    def test_clear_db_clears_collections(self):
        """Tests that clear_db deletes all documents from all NoSQL collections."""
        python_program.clear_db()
        self.customers.delete_many.assert_called_once_with({})
        self.drivers.delete_many.assert_called_once_with({})
        self.orders.delete_many.assert_called_once_with({})
        self.dockets.delete_many.assert_called_once_with({})

    #SQL DAILY SUMMARY TESTS
    def test_generate_daily_summary_inserts_when_none_exists(self):
        """Tests that generate_daily_summary inserts a new SQL record if none exists."""
        self.orders.find.return_value = [{"order_date": datetime.now(), "pizzas": [{"pizza_name": "Pepperoni", "price": 10, "quantity": 2}], "driver_id": ObjectId()}]
        self.drivers.find_one.return_value = {"commission_rate": 10.0}
        self.cursor.fetchone.return_value = None
        python_program.generate_daily_summary(self.sql_connection, date.today())
        self.cursor.execute.assert_any_call("SELECT total_orders FROM Pizzeria_Daily_Summaries WHERE summary_date = ?", (date.today(),))
        self.sql_connection.commit.assert_called_once()

    def test_generate_daily_summary_updates_existing(self):
        """Tests that generate_daily_summary updates an existing SQL record if one is found."""
        self.orders.find.return_value = [{"order_date": datetime.now(), "pizzas": [{"pizza_name": "Hawaiian", "price": 12, "quantity": 1}], "driver_id": ObjectId()}]
        self.drivers.find_one.return_value = {"commission_rate": 10.0}
        self.cursor.fetchone.return_value = [5]
        python_program.generate_daily_summary(self.sql_connection, date.today())
        self.sql_connection.commit.assert_called_once()

    #PDF GENERATION TESTS
    @patch("python_program.canvas.Canvas")
    @patch("os.makedirs")
    def test_generate_pdf_from_order_creates_pdf(self, mock_mkdir, mock_canvas):
        """Tests that PDF generation is triggered correctly for a given order."""
        fake_order_id = str(ObjectId())
        self.dockets.find.return_value = [{
            "docket_type": "Cooking",
            "order_id": fake_order_id,
            "order_date": "2024-01-01",
            "customer_info": {"first_name": "John", "last_name": "Doe", "email": "x"},
            "ordered_items": [{"pizza_name": "Pepperoni", "quantity": 1, "price": 10, "size": "M"}],
            "status": "Cooking"
        }]
        python_program.generate_pdf_from_order(fake_order_id)
        mock_mkdir.assert_called_once()
        mock_canvas.assert_called_once()

    #VIEW FUNCTION TESTS
    def test_view_drivers_prints_active(self):
        """Tests that view_drivers prints all active drivers."""
        self.drivers.find.return_value = [{"name": "Bob", "delivery_suburbs": ["A"], "commission_rate": 10.0}]
        with patch("builtins.print") as mock_print:
            python_program.view_drivers()
        mock_print.assert_any_call("\n:::: ACTIVE DRIVERS ::::")

    def test_view_order_no_orders(self):
        """Tests that view_order prints a message when no orders are found."""
        self.orders.find.return_value = []
        with patch("builtins.print") as mock_print:
            python_program.view_order()
        mock_print.assert_any_call("\nNo orders were  found in the database.\n")

    def test_view_sql_summaries_with_data(self):
        """Tests that view_sql_summaries prints existing SQL summary data."""
        rows = [(date.today(), 5, 100.0, "Pepperoni", 10.0)]
        self.cursor.fetchall.return_value = rows
        with patch("builtins.print") as mock_print:
            python_program.view_sql_summaries(self.sql_connection)
        mock_print.assert_any_call("\n :::: DAILY SUMMARIES (SQL) ::::")

    def test_view_sql_summaries_none_then_generate(self):
        """Tests that view_sql_summaries calls generate_daily_summary if no summaries exist."""
        self.cursor.fetchall.side_effect = [[], [(date.today(), 1, 50.0, "Hawaiian", 5.0)]]
        with patch("builtins.print"):
            with patch.object(python_program, "generate_daily_summary") as mock_gen:
                python_program.view_sql_summaries(self.sql_connection)
        mock_gen.assert_called_once()

#CUSTOM TEST RESULT AND RUNNER
class CustomTestResult(unittest.TextTestResult):
    """Overrides default test result to display 'PASS' for successful tests inline."""
    def addSuccess(self, test):
        super().addSuccess(test)
        self.stream.write("PASS ")
        self.stream.flush()

class CustomTestRunner(unittest.TextTestRunner):
    """Uses CustomTestResult as the result class for the test runner."""
    resultclass = CustomTestResult

#TEST SUITE EXECUTION ENTRY POINT
if __name__ == "__main__":
    unittest.main(testRunner = CustomTestRunner, verbosity = 2)